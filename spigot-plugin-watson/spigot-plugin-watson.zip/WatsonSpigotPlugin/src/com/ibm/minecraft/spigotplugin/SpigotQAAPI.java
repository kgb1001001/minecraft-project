package com.ibm.minecraft.spigotplugin;

import java.io.BufferedReader;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.codec.binary.Base64;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;

public class SpigotQAAPI {
	private static final Logger logger = Logger.getLogger(SpigotQAAPI.class.getName());
	
	/*
	 Insert the credentials for the Watson Question and Answer service
	 credentials": {
       	 "url": "https://gateway.watsonplatform.net/question-and-answer-beta/api",
		 "username": "",
    	 "password": ""
      	}
	 */
	//static String QAAPI_URL = "https://gateway.watsonplatform.net/question-and-answer-beta/api/v1/question/healthcare";
	//static String QA_USERNAME = "0b62ca0c-cb62-4d98-ae29-dec74def30ab";
	//static String QA_PASSWORD = "6tXqf4NzufEf";
	static String QAAPI_URL = "";
	static String QA_USERNAME = "";
	static String QA_PASSWORD =	"";	
	static String BASIC_AUTH = "Basic " + new String(Base64.encodeBase64((QA_USERNAME+":"+QA_PASSWORD).getBytes()));
	
	/*
	* Create HTTP connection
	*/
	static public HttpURLConnection createConnection(String address, String method) throws IOException {
	URL url = new URL(address);
	HttpURLConnection connection = (HttpURLConnection)url.openConnection();
	if (method == "PUT" || method == "POST") {
	   connection.setDoOutput(true);
	}
	connection.setRequestMethod(method);
	connection.setRequestProperty("Authorization", BASIC_AUTH);
	connection.setRequestProperty("Accept", "application/json");
	connection.setRequestProperty("Content-Type", "application/json");

	return connection;
	}


	/* 
	 * Accepts as input a string of the question text, calls Watson
	 * QAAPI and returns the answer back as a String.
	 */
	public static String getQAAPIResponse(String questionText) {
	ObjectMapper mapper = new ObjectMapper();
	JsonNode resp=null;
	String ans=null;
	System.out.println("QAAPI url: " + QAAPI_URL);
	HttpURLConnection connection;
	try {

	connection = createConnection(QAAPI_URL,"POST");
	
	connection.setRequestProperty("X-SyncTimeout", "30");
	questionText = questionText.replaceAll("\"", "");
	questionText = "\"" + questionText + "\"";
	String s = "{ \"question\" : { \"questionText\" : " + questionText + "}}";
	
	JsonNode nd = mapper.readValue(s, JsonNode.class);
	
	connection.setInstanceFollowRedirects(false);
	OutputStream wr = connection.getOutputStream();
	wr.write(nd.toString().getBytes());
	wr.flush();
	wr.close();
	if (connection.getResponseCode() != HttpURLConnection.HTTP_CREATED &&
	connection.getResponseCode() != HttpURLConnection.HTTP_OK && 
	connection.getResponseCode() != HttpURLConnection.HTTP_MOVED_TEMP) {
	throw new RuntimeException("Failed : HTTP error code : "
	+ connection.getResponseCode());
	}

	BufferedReader br = new BufferedReader(new InputStreamReader(
	(connection.getInputStream())));

	String output=null;
	while ((output = br.readLine()) != null) {
		resp = mapper.readValue(output, JsonNode.class);
		if(resp == null) {
		logger.log(Level.WARNING,"system response is null");
		} else {
	//	ans = resp.get(0).get("question").get("evidencelist").get(0).get("text").toString();
		ans = resp.get("question").get("evidencelist").get(0).get("text").toString();
		}
	}
	connection.disconnect();
	} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	}
	return ans;
	}	
}
