/**
 * 
 */
package com.ibm.minecraft.spigotplugin;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * @author kozhaya
 *
 */

public class WatsonQA extends JavaPlugin {
	// Fired when plugin is first enabled
	@Override
	public void onEnable() {
		getLogger().info("WatsonSpigotPlugin");
	}
	// Fired when plugin is disabled
	@Override
	public void onDisable() {
    }
	    
	public boolean onCommand(CommandSender sender, Command cmd, String label,
			String[] args) {
		getLogger().info("command: " + cmd.getName());
		//getServer().dispatchCommand(getServer().getConsoleSender(), cmd.getName());
		if (cmd.getName().equalsIgnoreCase("hello")) {
			sender.sendMessage("Hello Watson");
		}
		if (cmd.getName().equalsIgnoreCase("watson")) {
			if (args.length == 0) {
				sender.sendMessage("WATSON Rocks");
				return true;
			} 
			
			if (args.length >= 1) {
				StringBuilder str = new StringBuilder();
				for(int i=0; i < args.length; i++) {
					str.append(args[i]);
					if(i < args.length-1) {
						str.append(" ");
					}
				}
				String question = str.toString();
				sender.sendMessage("asking Watson: " + question);
				String response = SpigotQAAPI.getQAAPIResponse(question);
				sender.sendMessage("Watson response: " + response);
				
				return true;				
			}
				
		}
		return false;
	}
}
